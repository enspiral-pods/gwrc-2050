def Model.last_modified_date() @last_modified_date ||= Time.utc(*[31, 41, 19, 13, 12, 2015, 0, 347, true, "NZDT"]); end
