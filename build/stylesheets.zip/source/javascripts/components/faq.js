define(['knockout', 'text!../../components/faq-overlay.html'], function(ko, html) {
  'use strict';

  var ViewModel = function(params) {

  };

  return {
    viewModel: ViewModel,
    template: html
  };

});
